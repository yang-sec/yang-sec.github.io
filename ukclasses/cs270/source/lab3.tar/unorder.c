#include <stdio.h>     /* for printf() */
#include <sys/types.h> /* for pid_t */
#include <unistd.h> /* for fork() */
#include <stdlib.h> /* for exit() */
#include <signal.h> /* for signal(), sig_atomic_t, SIGUSR1 */

void DieWithError(char *errstring) {
  fprintf(stderr,"%s\n",errstring);
  exit(1);
}
  
int main() {
  pid_t pid;

  if ((pid = fork()) < 0)
    DieWithError("fork() failed");

  if (pid != 0) { /* parent -  pid is child process ID */
    puts("Event 1"); fflush(stdout);
    puts("Event 3"); fflush(stdout);
    exit(0);
  } else { /* child */
    puts("Event 2"); fflush(stdout);
    puts("Event 4"); fflush(stdout);
    exit(0);
  }
}
