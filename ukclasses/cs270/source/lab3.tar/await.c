#include <stdio.h>
#include <signal.h>
#include <unistd.h>
/* Signal-handling routines. */
/* See guidelines G4 and G5 in Section 8.5 of the textbook */

void DieWithError(char *msg);  // defined in main

static volatile int eventdone = 0;

void usr1handler(int sig) {
  eventdone = 1;
}

void setup_handler(int sig) {
  struct sigaction myaction;

  myaction.sa_handler = usr1handler;
  myaction.sa_flags = 0;
  // block everything while handler is running
  if (sigfillset(&myaction.sa_mask) < 0)
    DieWithError("sigfillset");

  /* third argument is NULL b/c we don't care about previous disposition */
  if (sigaction(sig,&myaction,NULL) < 0)
    DieWithError("sigaction");

}

/* wait for eventdone to become true.
 * Precondition: handler established
 */
void await_event(void) {
  /* wait for handler to run when SIGUSR1 is delivered */
  while (!eventdone)  // handler has not run yet
    pause();
  /* SIGUSR1 was handled - reset the flag */
  eventdone = 0;
}


