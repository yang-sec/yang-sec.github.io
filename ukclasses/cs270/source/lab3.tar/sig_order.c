#include <stdio.h>     /* for printf() */
#include <sys/types.h> /* for pid_t */
#include <unistd.h> /* for fork() */
#include <stdlib.h> /* for exit() */
#include <signal.h> /* for signal(), sig_atomic_t, SIGUSR1 */

void DieWithError(char *errstring) {
  perror(errstring); // expect errno to be set when this is called.
  exit(1);
}

volatile int eventdone = 0;
void usr1handler(int ignored) { // we only expect SIGUSR1
  eventdone = 1;
}

int main() {
  pid_t pid;

  /* set up signal handler BEFORE forking. Child inherits signal disposition */
  if (signal(SIGUSR1,usr1handler) < 0)
    DieWithError("signal");
    
  if ((pid = fork()) < 0)
    DieWithError("fork()");

  if (pid != 0) { /* parent -  pid is child process ID */
    puts("Event 1"); fflush(stdout);
    if (kill(pid,SIGUSR1)<0) /*  let child know event 1 has occurred. */
      DieWithError("kill 1");
    /* N.B.: changes to eventdone in child do NOT affect *our* eventdone! */
    /* - so eventdone is 0 until handler  runs in this process.            */
    // wait for child to tell us event 2 has occurred.
    while (!eventdone)
      pause();  // suspend execution until a signal is delivered.
    // SIGUSR1 arrived => child did event 2
    puts("Event 3"); fflush(stdout);
  } else { /* pid == 0 => child process */
    /* wait for indication that Event 1 has occurred */
    while (!eventdone)
      pause();
    // SIGUSR1 arrived => parent did Event 1
    puts("Event 2"); fflush(stdout);
    kill(getppid(),SIGUSR1); // tell parent
    puts("Event 4"); fflush(stdout);
  }
  exit(0);
}
