#include <stdio.h>     /* for printf() */
#include <sys/types.h> /* for pid_t */
#include <unistd.h> /* for fork() */
#include <stdlib.h> /* for exit() */
#include <signal.h> /* for signal(), SIGUSR1 */

// these functions  are defined in await.c
void setup_handler(int sig);
void await_event(void);

void DieWithError(char *errstring) {
  perror(errstring); // expect errno to be set when this is called.
  exit(1);
}

int main() {
  pid_t pid;

  /* set up signal handler BEFORE forking. Child inherits signal disposition */
  setup_handler(SIGUSR1);
    
  if ((pid = fork()) < 0)
    DieWithError("fork()");

  if (pid != 0) { /* parent -  pid is child process ID */
    puts("Event 1"); fflush(stdout);
    kill(pid,SIGUSR1); // let child know event 1 has occurred.
    /* note: changes to eventdone in child do NOT affect our copy */
    // wait for child to tell us event 2 has occurred.
    await_event();
    /* handler ran => Child did Event 2 */
    puts("Event 3"); fflush(stdout);
    kill(pid,SIGUSR1);

  } else { /* pid == 0 => this is the child */
    /* wait for indication that Event 1 has occurred */
    await_event();
    puts("Event 2"); fflush(stdout);
    kill(getppid(),SIGUSR1);
    await_event();
    puts("Event 4"); fflush(stdout);
  }
  /* our work is done */
  return 0;
}
