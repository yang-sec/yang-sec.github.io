#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv) {
  int rv;
  struct stat mystat;
  if (argc != 2) {
    fprintf(stderr,"Usage: %s <filename>\n",argv[0]);
    return 1;
  }
  rv = stat(argv[1],&mystat);
  
  /* YOUR CODE HERE: add a statement to use fields of mystat
   * to print output like this: 
   * "The size of ⟨filename⟩ is ⟨#⟩ bytes, and the uid of its owner is ⟨id#⟩."
   */
  

  return 0;
}
