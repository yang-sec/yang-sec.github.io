#include "filelab.h"

void DieWithError(char *s) {
  perror(s);
  exit(9);
}

uint32_t read_filecount(int fd) {
  uint32_t tmp;
  if (lseek(fd,0,SEEK_SET) < 0)
    DieWithError("lseek for read");
  if (read(fd,&tmp,sizeof(tmp)) < sizeof(tmp))
    DieWithError("short read");
  return tmp;
}

void write_filecount(int fd,uint32_t value) {
  if (lseek(fd,0,SEEK_SET) < 0)
    DieWithError("lseek for write");
  if (write(fd,&value,sizeof(value)) < sizeof(value))
    DieWithError("short write");
}

/* get exclusive access by creating a lock file                   */
/* when this function returns, this process has exclusive access. */
void acquire_lock(void) {
  int fd;
  do {
    fd = open(LOCKFILENAME,O_WRONLY|O_CREAT|O_EXCL,0777);
  } while (fd < 0 && errno == EEXIST);
  if (fd < 0)
    DieWithError("could not create lockfile");
  close(fd);
}

/* give up exclusive access to the file be deleting the lock file */
/* When this returns, other procs may be accessing the file */
void release_lock(void) {
  if (unlink(LOCKFILENAME) < 0)
    DieWithError("could not delete lockfile");
}

int main() {
  int i,fildes;
  uint32_t mycount=0;
  uint32_t filecount;
  uint32_t increment;
  size_t bufsize = sizeof(mycount);
  pid_t pid;

  fildes = open(FILENAME,O_RDWR|O_CREAT,0777);
  if (fildes < 0)
    DieWithError(FILENAME);
  /* initialize the count in the file to 0 */
  if (write(fildes,&mycount,sizeof(mycount)) < sizeof(mycount))
    DieWithError("initial write failed.");

  if ((pid = fork()) < 0)
    DieWithError("fork failed");
  /* now there are two procs updating the count */

  for (i=0; i<ITERCOUNT; i++) {
    /* get a random increment in [0-255] */
    if (getrandom(&increment,bufsize,0) < bufsize)
      DieWithError("getrandom: short");
    increment &= 0xff;   /* truncate increment to < 256 */
    /* keep track of the increments *I* add */
    mycount += increment;

    /* read the current value of the count from the file */
    filecount = read_filecount(fildes);
    /* add the random increment */
    filecount += increment;
    /* write it back to the file */
    write_filecount(fildes,filecount);

  }
  if (!pid) { // child
    printf("child's total count: %d\n",mycount);
    exit(0);
  }

  /* parent only continues */
  printf("parent's total count: %d\n",mycount);
  if (wait(NULL) < 0)
    DieWithError("This cannot happen!?");
  /* get the file size */
  printf("Final count in file = %d\n",read_filecount(fildes));

  close(fildes);
  exit(0);
}
    
