#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/random.h>
#include <sys/wait.h>
#include <errno.h>

#define FILENAME "countfile"
#define LOCKFILENAME "countfilelock"
#define ITERCOUNT 100

